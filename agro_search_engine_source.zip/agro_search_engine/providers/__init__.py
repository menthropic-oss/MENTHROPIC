"""Search provider adapters."""
