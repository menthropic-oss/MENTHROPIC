"""AGRO Search Engine Telegram bot."""

__version__ = "1.0.0"
